# tasks/resource_mapping.py
from .task import Task
import os
import json
import pickle
import requests
import numpy as np
import openai
from tqdm import tqdm
from openai import OpenAI
openai_client = OpenAI(api_key="")



class ResourceMappingsGenerator:
    def __init__(self, output_file='resource_mappings.json'):
        self.output_file = output_file
        self.resource_spec = None
        self.categories = self.get_categories()
        self.resource_mappings = {}
        self.download_resource_specification()
        self.generate_resource_mappings()

    def download_resource_specification(self):
        """
        Downloads the AWS CloudFormation Resource Specification JSON.
        """
        spec_url = 'https://d1uauaxba7bl26.cloudfront.net/latest/gzip/CloudFormationResourceSpecification.json'
        try:
            response = requests.get(spec_url)
            if response.status_code == 200:
                self.resource_spec = response.json()
                print("Successfully downloaded resource specification.")
            else:
                raise Exception(f"Failed to download resource specification. Status code: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
            self.resource_spec = None

    def get_categories(self):
        """
        Returns a list of categories.
        """
        return [
            'Security',
            'Compliance',
            'Reliability',
            'Performance Efficiency',
            'Cost Optimization',
            'Operational Excellence',
            'Sustainability',
            'Risk Management',
            'Continuous Monitoring',
            'Other'
        ]

    def assign_categories(self, prop_name, prop_details):
        """
        Assigns categories to a property using GPT-3.5.

        Args:
            prop_name (str): The name of the property.
            prop_details (dict): The details of the property from the resource specification.

        Returns:
            List[str]: A list of categories assigned to the property.
        """
        openai.api_key = os.getenv('OPENAI_API_KEY')  # Ensure API key is set

        # Prepare the messages for GPT-3.5
        system_message = "You are an expert in AWS CloudFormation templates and the AWS Well-Architected Framework."
        user_message = f"""
You will be provided with an AWS CloudFormation property name and its description. Your task is to assign all relevant categories from the provided list of categories to this property. The categories are:

{', '.join(self.categories)}

Property Name: "{prop_name}"

Property Description: "{prop_details.get('Documentation', 'No description available')}"

Assign all relevant categories to the property from the list of categories. Provide the categories as a JSON array.

Example Response:
["Security", "Compliance"]

Provide only the JSON array of categories in your response.
"""

        try:
            messages = [
                    {"role": "system", "content": system_message},
                    {"role": "user", "content": user_message}
                ]
            response = openai_client.chat.completions.create(
                model='gpt-3.5-turbo',  # Ensure you have access to this model
                messages=messages,
                max_tokens=500,
                temperature=0.7
            )
            output = response.choices[0].message.content.strip()
            # Parse the output as JSON
            categories = json.loads(output)
            # Validate categories
            valid_categories = [cat for cat in categories if cat in self.categories]
            if not valid_categories:
                valid_categories = ['Other']
            return valid_categories
        except Exception as e:
            print(f"Error assigning categories for property '{prop_name}': {e}")
            return ['Other']

    def generate_resource_mappings(self):
        """
        Generates mappings for all resources and their properties.
        """
        if not self.resource_spec:
            print("Resource specification is not available.")
            return

        resource_types = self.resource_spec.get('ResourceTypes', {})
        total_properties = sum(len(details.get('Properties', {})) for details in resource_types.values())
        processed_properties = 0

        for resource_type, resource_details in resource_types.items():
            properties = resource_details.get('Properties', {})
            property_mappings = {}
            for prop_name, prop_details in properties.items():
                categories = self.assign_categories(prop_name, prop_details)
                property_mappings[prop_name] = categories
                processed_properties += 1
                if processed_properties % 50 == 0:
                    print(f"Processed {processed_properties}/{total_properties} properties...")

            self.resource_mappings[resource_type] = property_mappings

        self.save_mappings_to_file()

    def save_mappings_to_file(self):
        """
        Saves the resource mappings to a JSON file.
        """
        try:
            with open(self.output_file, 'w') as f:
                json.dump(self.resource_mappings, f, indent=4)
            print(f"Resource mappings saved to {self.output_file}")
        except Exception as e:
            print(f"Error writing to file: {e}")

class ResourceMappingsGeneratorNonAI:
    def __init__(self, output_file='resource_mappings.json'):
        self.output_file = output_file
        self.resource_spec = None
        self.mapping_rules = self.get_mapping_rules()
        self.resource_mappings = {}
        self.download_resource_specification()
        self.generate_resource_mappings()

    def download_resource_specification(self):
        """
        Downloads the AWS CloudFormation Resource Specification JSON.
        """
        spec_url = 'https://d1uauaxba7bl26.cloudfront.net/latest/gzip/CloudFormationResourceSpecification.json'
        try:
            response = requests.get(spec_url)
            if response.status_code == 200:
                self.resource_spec = response.json()
                print("Successfully downloaded resource specification.")
            else:
                raise Exception(f"Failed to download resource specification. Status code: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
            self.resource_spec = None

    def get_mapping_rules(self):
        """
        Returns the mapping rules for categorization.
        """
        return {
            'Security': [
                'KmsKey', 'Encryption', 'Access', 'Policy', 'Auth', 'IAM',
                'Public', 'Private', 'Security', 'Ssl', 'Tls', 'Certificate',
                'SubnetMappings', 'Scheme', 'IpAddressType', 'MFA', 'Role'
            ],
            'Compliance': [
                'Compliance', 'Audit', 'Logging', 'Log', 'Versioning', 'Retention', 'Regulatory'
            ],
            'Reliability': [
                'Backup', 'Retention', 'Replication', 'Recovery', 'Redundancy',
                'Timeout', 'Retry', 'HealthCheck', 'AvailabilityZones', 'Subnets',
                'Failover', 'AZ', 'Region'
            ],
            'PerformanceEfficiency': [
                'Throughput', 'Latency', 'Performance', 'Shard', 'Capacity',
                'Read', 'Write', 'LoadBalancerAttributes', 'Type', 'Scaling',
                'Optimization', 'AutoScaling'
            ],
            'CostOptimization': [
                'Cost', 'Price', 'Billing', 'Usage', 'Provisioned', 'Reserved', 'Spot'
            ],
            'OperationalExcellence': [
                'Tag', 'Name', 'Description', 'Parameter', 'Config', 'Documentation',
                'VersionControl', 'Pipeline', 'CI/CD'
            ],
            'Sustainability': [
                'Efficiency', 'Energy', 'Sustainability', 'Carbon', 'Green'
            ],
            'RiskManagement': [
                'Risk', 'Threat', 'Vulnerability', 'Mitigation', 'Exposure'
            ],
            'ContinuousMonitoring': [
                'Monitoring', 'Alert', 'Event', 'Notification', 'Alarm', 'Metric', 'Trace'
            ],
            'Other': []
        }

    def categorize_property(self, prop_name):
        """
        Categorizes a property based on the mapping rules.
        """
        prop_name_lower = prop_name.lower()
        for category, keywords in self.mapping_rules.items():
            for keyword in keywords:
                if keyword.lower() in prop_name_lower:
                    return category
        return 'Other'

    def generate_resource_mappings(self):
        """
        Generates mappings for all resources and their properties.
        """
        if not self.resource_spec:
            print("Resource specification is not available.")
            return

        resource_types = self.resource_spec.get('ResourceTypes', {})
        for resource_type, resource_details in resource_types.items():
            properties = resource_details.get('Properties', {})
            property_mappings = {}
            for prop_name in properties.keys():
                category = self.categorize_property(prop_name)
                property_mappings[prop_name] = category
            self.resource_mappings[resource_type] = property_mappings

        self.save_mappings_to_file()

    def save_mappings_to_file(self):
        """
        Saves the resource mappings to a JSON file.
        """
        try:
            with open(self.output_file, 'w') as f:
                json.dump(self.resource_mappings, f, indent=4)
            print(f"Resource mappings saved to {self.output_file}")
        except Exception as e:
            print(f"Error writing to file: {e}")

class ResourceMappingTask(Task):
    def run(self, input_data):
        if input_data == 'yes':
            generator = ResourceMappingsGenerator()
        if input_data == 'no':
            generator = ResourceMappingsGeneratorNonAI()
        # Perform resource mapping (replace this with the actual mapping logic)
        return f"Resource mapping completed."
    
# if __name__ == '__main__':
#     app = ResourceMappingTask()
#     app.run('yes')
