# tasks/rag_related_code.py
from .task import Task
import os
import csv
import json
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm
import numpy as np
from openai import OpenAI
openai_client = OpenAI(api_key="")


# Suppress tokenizer warnings if any
os.environ["TOKENIZERS_PARALLELISM"] = "false"

class RAGTask(Task):
    def read_links(self, file_path):
        with open(file_path, 'r') as f:
            lines = f.readlines()

        links = []
        for line in lines:
            line = line.strip()
            if line.startswith('http'):
                links.append(line)
        return links

    def fetch_content(self, links):
        documents = []
        headers = {
            'User-Agent': 'Mozilla/5.0'
        }

        for link in tqdm(links, desc='Fetching content'):
            try:
                response = requests.get(link, headers=headers, timeout=10)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
                # Remove script and style elements
                for script_or_style in soup(['script', 'style']):
                    script_or_style.decompose()
                text = ' '.join(soup.stripped_strings)
                documents.append({
                    'url': link,
                    'content': text
                })
            except requests.RequestException as e:
                print(f"Error fetching {link}: {e}")
                continue
        return documents

    def get_embeddings(self, documents):
        embeddings = []
        for doc in tqdm(documents, desc='Generating embeddings'):
            try:
                # Truncate content to maximum allowed by the embedding model
                max_tokens = 8192  # Adjust based on OpenAI's max tokens for embeddings
                content = doc['content'][:max_tokens]
                response = openai_client.embeddings.create(
                    input=content,
                    model='text-embedding-ada-002'
                )
                embedding = response.data[0].embedding
                embeddings.append({
                    'url': doc['url'],
                    'content': doc['content'],
                    'embedding': embedding
                })
            except Exception as e:
                print(f"Error generating embedding for {doc['url']}: {e}")
                continue
        return embeddings

    def save_embeddings_to_csv(self, embeddings, filename):
        fieldnames = ['url', 'content', 'embedding']
        try:
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(fieldnames)
                for item in embeddings:
                    writer.writerow([item['url'], item['content'], json.dumps(item['embedding'])])
            print(f"Embeddings saved to {filename}")
        except Exception as e:
            print(f"Error writing embeddings to CSV: {e}")

    def load_embeddings_from_csv(self, filename):
        embeddings = []
        try:
            with open(filename, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    embeddings.append({
                        'url': row['url'],
                        'content': row['content'],
                        'embedding': json.loads(row['embedding'])
                    })
            print(f"Embeddings loaded from {filename}")
        except Exception as e:
            print(f"Error reading embeddings from CSV: {e}")
        return embeddings

    def find_relevant_documents(self, embeddings, query_embedding, top_k=5):
        # Calculate cosine similarity between the query embedding and document embeddings
        try:
            query_embedding = np.array(query_embedding)
            doc_embeddings = np.array([np.array(doc['embedding']) for doc in embeddings])
            similarities = np.dot(doc_embeddings, query_embedding) / (np.linalg.norm(doc_embeddings, axis=1) * np.linalg.norm(query_embedding))
            # Get the indices of the top_k most similar documents
            top_k_indices = similarities.argsort()[-top_k:][::-1]
            relevant_docs = [embeddings[i] for i in top_k_indices]
            return relevant_docs
        except Exception as e:
            print(f"Error finding relevant documents: {e}")
            return []

    def generate_answer(self, context, query):
        messages = [
            {"role": "system", "content": "You are an expert on AWS services."},
            {"role": "user", "content": f"Context:\n{context}\n\nQuestion:\n{query}\n\nAnswer in a detailed and informative manner."}
        ]

        try:
            response = openai_client.chat.completions.create(
                model='gpt-3.5-turbo',  # Use a model you have access to
                messages=messages,
                max_tokens=500,
                temperature=0.7,
            )
            answer = response.choices[0].message.content.strip()
            return answer
        except Exception as e:
            print(f"Error generating answer: {e}")
            return "I'm sorry, but I cannot provide an answer at this time."

    def run(self, input_data):
        # Perform RAG (replace this with the actual RAG logic)

        # Step 1: Read links from the file
        file_path = 'artifacts/service_blogs.txt'  # Replace with your file
        links = self.read_links(file_path)
        print(f"Total links found: {len(links)}")

        # Step 2: Fetch and process content
        documents = self.fetch_content(links)
        print(f"Total documents fetched: {len(documents)}")

        if not documents:
            print("No documents to process. Exiting.")
            return

        embeddings_file = 'artifacts/embeddings.csv'

        # Step 3: Generate embeddings or load if they exist
        if os.path.exists(embeddings_file):
            print("Embeddings file found. Loading embeddings...")
            embeddings = self.load_embeddings_from_csv(embeddings_file)
            print(f"Total embeddings loaded: {len(embeddings)}")
        else:
            embeddings = self.get_embeddings(documents)
            print(f"Total embeddings generated: {len(embeddings)}")

            if not embeddings:
                print("No embeddings generated. Exiting.")
                return

            # Save embeddings to CSV
            self.save_embeddings_to_csv(embeddings, embeddings_file)

        # Step 4: Interactive query loop
        print("\nYou can now ask questions about the AWS service.")
        while True:
            query = input("\nEnter your question (or type 'exit' to quit): ")
            if query.lower() in ['exit', 'quit']:
                break
            try:
                # Generate embedding for the query
                response = openai_client.embeddings.create(
                    input=query,
                    model='text-embedding-ada-002'
                )
                query_embedding = response.data[0].embedding

                # Find relevant documents
                relevant_docs = self.find_relevant_documents(embeddings, query_embedding, top_k=5)
                if not relevant_docs:
                    print("No relevant documents found.")
                    continue

                context = "\n\n".join([doc['content'] for doc in relevant_docs])

                answer = self.generate_answer(context, query)
                print("\nAnswer:")
                print(answer)
            except Exception as e:
                print(f"Error processing your query: {e}")
        return f"RAG processing for {query} completed."

# if __name__ == "__main__":
#     app = RAGTask()
#     app.run("security_data.txt")
