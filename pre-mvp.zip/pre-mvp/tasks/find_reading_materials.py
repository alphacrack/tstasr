# tasks/find_reading_materials.py
from .task import Task
import time
from urllib.parse import urlparse
from duckduckgo_search import DDGS



class FindReadingMaterialTask(Task):
    def generate_variations(self, service_name):
        """
        Generates variations of the AWS service name.
        """
        variations = set()
        base_variations = [
            service_name,
            service_name.lower(),
            service_name.upper(),
            f"AWS {service_name}",
            f"AWS {service_name}".lower(),
            f"AWS {service_name}".upper(),
            service_name.replace(' ', ''),
            f"AWS{service_name.replace(' ', '')}",
            f"{service_name} service",
            f"Amazon {service_name}",
            f"Amazon {service_name}".lower(),
            f"Amazon {service_name}".upper(),
        ]
        variations.update(base_variations)
        return list(variations)

    def search_duckduckgo(self, query, max_results=10):
        """
        Uses the duckduckgo_search package to perform the search.
        """
        ddgs = DDGS()
        results = ddgs.text(query, max_results=max_results)
        links = []
        for result in results:
            links.append(result['href'])
        return links

    def categorize_links(self, links):
        """
        Categorizes links based on their domain.
        """
        categories = {
            'AWS': [],
            'Medium': [],
            'Other': []
        }

        for link in links:
            domain = urlparse(link).netloc.lower()
            if 'aws.amazon.com' in domain or 'amazon.com' in domain:
                categories['AWS'].append(link)
            elif 'medium.com' in domain:
                categories['Medium'].append(link)
            else:
                categories['Other'].append(link)
        return categories


    def run(self, input_data):
        # Placeholder for logic from find_reading_materials.py
        service_name = input_data
        # code to search the links

        variations = self.generate_variations(service_name)
        print("\nGenerated Variations for Search:")
        for variation in variations:
            print(f"- {variation}")

        all_links = set()
        for variation in variations:
            query = f"{variation} blog"
            print(f"\nSearching for '{query}'...")
            links = self.search_duckduckgo(query, max_results=20)
            print(f"Found {len(links)} links.")
            all_links.update(links)
            time.sleep(1)  # Be polite and avoid overwhelming the server

        print(f"\nTotal unique links found: {len(all_links)}")

        categorized_links = self.categorize_links(all_links)

        print("\nCategorized Links:")
        for category, links in categorized_links.items():
            print(f"\n{category} ({len(links)} links):")
            for link in links:
                print(f"- {link}")

        # Save the results to a file
        output_file = "artifacts/service_blogs.txt"
        with open(output_file, 'w') as f:
            for category, links in categorized_links.items():
                f.write(f"{category} ({len(links)} links):\n")
                for link in links:
                    f.write(f"{link}\n")
                f.write("\n")
        print(f"\nLinks saved to {output_file}")
        # Perform search for reading material (replace this with actual search logic)
        return f"Reading material search for {service_name} completed."
    
# if __name__ == "__main__":

#     service_name = input("Enter the AWS service name: ").strip()
#     app = FindReadingMaterialTask()
#     app.run(service_name)
