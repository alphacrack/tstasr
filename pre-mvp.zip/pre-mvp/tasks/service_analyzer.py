# tasks/service_analyzer.py
from .task import Task
import os
import csv
import json
import requests
import numpy as np
import openai
from tqdm import tqdm
from openai import OpenAI
openai_client = OpenAI(api_key="")


class AWSServiceAnalyzer:
    def __init__(self, resource_type, mappings_file='resource_mappings.json', embeddings_file='embeddings.csv', output_file='service_configuration_report.txt'):
        """
        Initialize the AWSServiceAnalyzer with the specified AWS resource type.
        """
        self.resource_type = resource_type
        self.mappings_file = mappings_file
        self.embeddings_file = embeddings_file
        self.output_file = output_file
        self.resource_spec = None
        self.properties = None
        self.categorized_properties = {}
        self.resource_mappings = self.load_resource_mappings()
        self.download_resource_specification()
        self.extract_service_properties()
        self.load_blog_post_embeddings()
        self.categorize_properties()
        self.generate_comments()

    def load_resource_mappings(self):
        """
        Loads the resource mappings from the JSON file.
        """
        try:
            with open(self.mappings_file, 'r') as f:
                mappings = json.load(f)
            print(f"Successfully loaded resource mappings from {self.mappings_file}")
            return mappings
        except Exception as e:
            print(f"Error loading resource mappings: {e}")
            return {}

    def download_resource_specification(self):
        """
        Downloads the AWS CloudFormation Resource Specification JSON.
        """
        spec_url = 'https://d1uauaxba7bl26.cloudfront.net/latest/gzip/CloudFormationResourceSpecification.json'
        try:
            response = requests.get(spec_url)
            if response.status_code == 200:
                self.resource_spec = response.json()
                print("Successfully downloaded resource specification.")
            else:
                raise Exception(f"Failed to download resource specification. Status code: {response.status_code}")
        except Exception as e:
            print(f"Error: {e}")
            self.resource_spec = None

    def extract_service_properties(self):
        """
        Extracts properties of the specified AWS service from the resource specification.
        """
        if not self.resource_spec:
            print("Resource specification is not available.")
            return

        self.service = self.resource_spec['ResourceTypes'].get(self.resource_type)
        if self.service:
            self.properties = self.service.get('Properties', {})
        else:
            print(f"{self.resource_type} not found in the resource specification.")
            self.properties = None

    def load_blog_post_embeddings(self):
        """
        Loads the blog post embeddings from CSV.
        """
        embeddings_file = self.embeddings_file

        if os.path.exists(embeddings_file):
            print("Loading blog post embeddings from CSV...")
            self.blog_embeddings = self.load_embeddings_from_csv(embeddings_file)
            print(f"Blog post embeddings loaded. Total embeddings: {len(self.blog_embeddings)}")
        else:
            print("Blog post embeddings CSV not found.")
            self.blog_embeddings = []

    def load_embeddings_from_csv(self, filename):
        embeddings = []
        try:
            with open(filename, 'r', newline='', encoding='utf-8') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    embeddings.append({
                        'url': row['url'],
                        'content': row['content'],
                        'embedding': json.loads(row['embedding'])
                    })
            return embeddings
        except Exception as e:
            print(f"Error reading embeddings from CSV: {e}")
            return []

    def categorize_properties(self):
        """
        Categorizes properties using the mappings from the JSON file,
        assigns risk levels, and provides reasoning.
        """
        if not self.properties:
            print("Service properties are not available.")
            return

        self.categorized_properties = {}  # Initialize as empty dictionary

        # Risk level mappings with reasoning
        risk_level_mappings = self.get_risk_level_mappings()

        # Get property mappings for the resource type
        property_mappings = self.resource_mappings.get(self.resource_type, {})

        for prop_name, prop_details in self.properties.items():
            categories = property_mappings.get(prop_name, ['Other'])
            if not isinstance(categories, list):
                categories = [categories]

            for category in categories:
                # Assign risk level and reasoning
                risk_level, reasoning = self.assign_risk_level(prop_name, category, risk_level_mappings)
                if category not in self.categorized_properties:
                    self.categorized_properties[category] = []
                self.categorized_properties[category].append({
                    'PropertyName': prop_name,
                    'PropertyDetails': prop_details,
                    'RiskLevel': risk_level,
                    'RiskReasoning': reasoning,
                    'Comment': '',  # Placeholder for comments
                    'NeedsThoroughCheck': risk_level <= 2  # Flag for properties that need thorough checking
                })

    def get_risk_level_mappings(self):
        """
        Defines risk levels and reasoning for specific properties or categories.
        """
        return {
            'Security': {
                'Critical': {
                    'keywords': ['Public', 'AdminAccess', 'Unauthenticated', 'OpenAccess'],
                    'reasoning': 'Critical security risk due to potential unauthorized access.'
                },
                'High': {
                    'keywords': ['Encryption', 'Private', 'Certificate', 'Scheme', 'Access', 'KmsKey'],
                    'reasoning': 'High security risk if not properly configured, leading to data exposure.'
                },
                'Medium': {
                    'keywords': ['Policy', 'IAM', 'Role', 'SecurityGroup', 'SubnetMappings'],
                    'reasoning': 'Medium security risk; misconfigurations could lead to vulnerabilities.'
                },
                'Low': {
                    'keywords': ['Tag', 'Description'],
                    'reasoning': 'Low security risk; minor impact on security posture.'
                }
            },
            # Risk level mappings for other categories can be defined similarly
        }

    def assign_risk_level(self, prop_name, category, risk_level_mappings):
        """
        Assigns a risk level and reasoning to a property based on its name and category.
        """
        risk_levels = {
            'Critical': 1,
            'High': 2,
            'Medium': 3,
            'Low': 4
        }

        category_risks = risk_level_mappings.get(category, {})
        for risk_name, risk_info in category_risks.items():
            keywords = risk_info.get('keywords', [])
            reasoning = risk_info.get('reasoning', 'No reasoning provided.')
            for keyword in keywords:
                if keyword.lower() in prop_name.lower():
                    return risk_levels[risk_name], reasoning
        # Default risk level and reasoning if not matched
        default_reasoning = f'Low risk as the property does not impact critical aspects in the {category} category.'
        return 4, default_reasoning  # Low risk

    def generate_comments(self):
        """
        Generates comments for each property using ChatGPT and relevant blog posts.
        """

        if not self.blog_embeddings:
            print("Blog post embeddings not available. Skipping comment generation from blog posts.")
            return

        print("\nGenerating comments for properties using ChatGPT...\n")

        for category, properties in self.categorized_properties.items():
            for prop in tqdm(properties, desc=f"Processing {category} properties"):
                prop_name = prop['PropertyName']
                prop_details = prop['PropertyDetails']
                needs_thorough_check = prop['NeedsThoroughCheck']

                # Find relevant blog posts
                relevant_blog_content = self.find_relevant_blog_content(prop_name)

                # Prepare the prompt for ChatGPT
                prompt = f"""
You are an AWS CloudFormation expert. Provide a detailed analysis of the property "{prop_name}" for the resource "{self.resource_type}". Include any important considerations, best practices, and potential pitfalls. Reference the following blog content if relevant:

{relevant_blog_content}

Also, indicate if this property requires thorough checking before implementation.

Property Details:
{json.dumps(prop_details, indent=4)}
"""

                try:
                    response = openai_client.chat.completions.create(
                        model='gpt-3.5-turbo',
                        messages=[
                            {"role": "system", "content": "You are an AWS CloudFormation expert."},
                            {"role": "user", "content": prompt}
                        ],
                        max_tokens=300,
                        temperature=0.7,
                    )
                    comment = response.choices[0].message.content.strip()
                    prop['Comment'] = comment
                except Exception as e:
                    print(f"Error generating comment for property '{prop_name}': {e}")
                    prop['Comment'] = "No comment available due to an error."

    def find_relevant_blog_content(self, prop_name, top_k=3):
        """
        Finds relevant blog content based on the property name.
        """
        if not self.blog_embeddings:
            return "No blog content available."

        try:
            # Generate embedding for the property name
            response = openai_client.embeddings.create(
                input=prop_name,
                model='text-embedding-ada-002'
            )
            prop_embedding = np.array(response.data[0].embedding, dtype='float32')

            # Compute similarities
            query_embedding = prop_embedding
            doc_embeddings = np.array([np.array(doc['embedding'], dtype='float32') for doc in self.blog_embeddings])
            similarities = np.dot(doc_embeddings, query_embedding) / (np.linalg.norm(doc_embeddings, axis=1) * np.linalg.norm(query_embedding))
            # Handle potential division by zero
            similarities = np.nan_to_num(similarities)

            # Get the indices of the top_k most similar documents
            top_k_indices = similarities.argsort()[-top_k:][::-1]
            relevant_blogs = [self.blog_embeddings[i] for i in top_k_indices]
            content_snippets = [blog['content'][:500] for blog in relevant_blogs]  # Limit to 500 chars each
            return "\n\n".join(content_snippets)
        except Exception as e:
            print(f"Error finding relevant blog content for '{prop_name}': {e}")
            return "No blog content available due to an error."

    def output_categorized_properties(self):
        """
        Outputs the categorized properties to a text file, including risk levels, reasoning, and comments.
        """
        try:
            with open(self.output_file, 'w') as file:
                file.write(f"AWS Service Configuration Report for {self.resource_type}\n")
                file.write("=" * 60 + "\n\n")
                for category, properties in self.categorized_properties.items():
                    file.write(f"{category}\n")
                    file.write("-" * len(category) + "\n")
                    if properties:
                        for prop in properties:
                            prop_name = prop['PropertyName']
                            prop_details = prop['PropertyDetails']
                            risk_level = prop['RiskLevel']
                            risk_reasoning = prop['RiskReasoning']
                            comment = prop['Comment']
                            needs_check = "Yes" if prop['NeedsThoroughCheck'] else "No"
                            file.write(f"Property: {prop_name}\n")
                            file.write(f"Risk Level: {risk_level}\n")
                            file.write(f"Needs Thorough Check: {needs_check}\n")
                            file.write(f"Reasoning: {risk_reasoning}\n")
                            file.write(f"Comment:\n{comment}\n")
                            file.write(f"Details:\n{json.dumps(prop_details, indent=4)}\n\n")
                    else:
                        file.write("No properties in this category.\n\n")
                print(f"\nReport generated successfully: {self.output_file}")
        except Exception as e:
            print(f"Error writing to file: {e}")

class ServiceAnalyzerTask(Task):
    def run(self, input_data):
        # Placeholder for logic from service_analyzer.py
        resource_type = input_data
        # Specify the AWS resource type you want to analyze
        analyzer = AWSServiceAnalyzer(resource_type)
        analyzer.output_categorized_properties()
        return f"Service analysis for {resource_type} completed."

# if __name__ == '__main__':
#     app = ServiceAnalyzerTask()
#     app.run('AWS::Lambda::Function')