# main.py
from task_factory import TaskFactory

def main():
    # Get user input for task type and input data
    task_type = input("Enter task type (find_reading_materials, instantiate_rag_for_services, aws_resource_mapping, aws_service_analyzer): ").strip()
    if task_type == 'find_reading_materials': 
        input_data = input("Enter input data for the task (e.g., AWS service name): ").strip()
    elif task_type == 'instantiate_rag_for_services': 
        input_data = input("Enter input data for the task (e.g., security related input file in .txt format): ").strip()
    elif task_type == 'aws_resource_mapping': 
        input_data = input("Enter input data for the task (e.g., use ai version (yes/no)): ").strip()
    elif task_type == 'aws_service_analyzer': 
        input_data = input("Enter input data for the task (e.g., AWS service identifier, first words , AWS::Lambda::)): ").strip()


    # Use the factory to create the appropriate task
    try:
        task = TaskFactory.create_task(task_type)
    except ValueError as e:
        print(e)
        return

    # Run the task and display the result
    result = task.run(input_data)
    print(result)

if __name__ == "__main__":
    while True:
        main()
