# task_factory.py
from tasks.service_analyzer import ServiceAnalyzerTask
from tasks.resource_mapping import ResourceMappingTask
from tasks.rag_related_code import RAGTask
from tasks.find_reading_materials import FindReadingMaterialTask

class TaskFactory:
    @staticmethod
    def create_task(task_type):
        if task_type == "aws_service_analyzer":
            return ServiceAnalyzerTask()
        elif task_type == "aws_resource_mapping":
            return ResourceMappingTask()
        elif task_type == "instantiate_rag_for_services":
            return RAGTask()
        elif task_type == "find_reading_materials":
            return FindReadingMaterialTask()
        else:
            raise ValueError(f"Unknown task type: {task_type}")
